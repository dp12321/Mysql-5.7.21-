package com.itheima.test;

public class Test2 {
    public static void main(String[] args){
        a1(-100);
    }

    public static void a1(int a){
        if(Math.abs(a)>1) {

            int a2 = a;
            a = Math.abs(a);
            if (a > 1) {
                for (int i = 2; i <= a; i++) {
                    boolean a1 = true;
                    for (int i1 = 2; i1 < i; i1++) {
                        if (i % i1 == 0) {
                            a1 = false;
                            break;
                        }
                    }
                    if (a1) {
                        if (a2 > 0)
                            System.out.println(i);
                        else
                            System.out.println(-i);
                    }
                }
            }
        }else{
            System.out.println(a+"既不是合数也不是质数");
        }
    }
}
