package com.itheima.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Collections;

//@Scope("prototype")
@Controller
public class Relay {

    //因为是单例，所以不写静态也是可以公用的。
     static ArrayList<String> list = new ArrayList<>();
     static int i = 0;

     Relay(){
         i++;
         System.out.println(i);
     }

      static ArrayList<String> list2 = new ArrayList<String>();

     //清空聊天缓存
    @ResponseBody
    @RequestMapping("docleardp")
    public String clear(){
        list.clear();
        return "clear";
    }



    //展示
    //@ResponseBody
    @RequestMapping("dov")
    public String view(Model model){
        //我觉的list一直是正向的。
        for(String a:list2){
           // System.out.print(a+"  ");
        }

        list2.clear();//得清理，不清理就反复录入。
        list2.addAll(list);
        Collections.reverse(list2);
        model.addAttribute("list1",list2);
        return "aa1";
    }

//调用一个方法，new一个对象
    //要莫就是一个对象。



    //输入
    //@ResponseBody
    @RequestMapping("do")
    public String relay(String text,Model model){
        System.out.println(text);
        list.add(text);

        model.addAttribute("list",list);
        return "redirect:index.html";
    }
}
