package com.itheima.test;

import java.util.ArrayList;
import java.util.Collections;

public class Test {

    static ArrayList<String> a = new ArrayList<>();
    static{
        a.add("1");
        a.add("2");
    }

    public static void main(String[] args){

        for(int i=0;i<10;i++){

            ArrayList<String> a2 = new  ArrayList<String>();
            a2.addAll(a);
           Collections.reverse(a2);
            for(String aa:a){
                System.out.print(aa+"  ");
            }
        }
    }
}
