package com.itheima.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;


//多例
@Scope("prototype")
@Controller//这个是跳转到网页，返回的不是文本
public class Login {

            Login(){
                System.out.println("构造方法调用");
            }

     //HashMap<String,String> table = new HashMap<String, String>();
    private static HashMap<String,String> table = new HashMap<String, String>();

    @ResponseBody
    @RequestMapping("login_02")
    public String login_02(){
        return "AA";
    }


    //通过方法访问静态页面

    int i=0;
    int j=0;
    //@ResponseBody//他是返回的字符串//无关方法参数的问题。
    @RequestMapping("doregister")//注册//访问方法时，还不能与静态资源的名字一样。
    public String register(String username,String password,Model model) {

        System.out.println("111111111111111111111111111122222222222222222222223333333333333333333333");
        if (username == "" || password == "") {//等于null或者等于空字符串都行。
            model.addAttribute("text", "请输入用户名和密码");
            i++;
            System.out.println(i + "重新注册111111111111111111111111111111");
            return "register1";//重新注册，并告诉出错的原因。
        } else {


            for(String a:table.keySet()){
                System.out.println(a+"############"+table.get(a));
                if(a.equals(username)){
                    System.out.println("我是董鹏");
                    model.addAttribute("text", username + "用户名已存在，请重新输入。。");
                    return "register1";
                }
            }


            table.put(username, password);
            model.addAttribute("nickname", username + ",注册成功！请登录");
            //model.addAttribute("nickname", username + "用户名已存在，请重新输入。。");
            System.out.println(j + "222222222222222222222222222222222#");
            //return "register1";
            return "redirect:login.html";
        }
    }


    //重定向


    int k=0;
    @RequestMapping("dologin")//登陆
    public String login(String username, String password,Model model){

        for(String a: table.keySet()){
            System.out.println("正确密码是总:"+a+table.get(a));
        }


        k++;
        for(String a: table.keySet()){System.out.println("正确密码是1:"+a+table.get(a));
            if(username.equals(a)&&table.get(a).equals(password)){//看来字符串输入比较得用equals
                System.out.println("正确密码是1:"+a+table.get(a));
                model.addAttribute("nickname",a+" 登录成功！");
                System.out.println(k+"**************************8");
                return "loginsucess";
                //return "https;//www.baidu.com";
            }
        }


            //System.out.println("正确密码是2："+a+table.get(a));
            model.addAttribute("nickname","登录失败！请重新输入密码。");
            return "login1";


    }

}
