package com.itheima.controller;

import com.itheima.bean.Goods;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import sun.reflect.generics.scope.Scope;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Controller
public class Shopping {


    //清空购物车
    @RequestMapping("doclear")
    public String clear(HttpServletRequest request){

        HttpSession session = request.getSession();
        session.invalidate();
        return "redirect:clear.html";
    }



    //提交
        int i=0;

    //@ResponseBody
    @RequestMapping("dosubmit")
    public String submit(HttpServletRequest request, HttpServletResponse response,Model model){

        HttpSession session2 = request.getSession();
        Map<Goods, Integer> map1=(Map<Goods,Integer>)session2 .getAttribute("cartlist");
        if(map1!=null){
            System.out.println("有");
        }else{
            System.out.println("无");
        }


            Cookie cookie = new Cookie("JSESSIONID",session2.getId());
            cookie.setMaxAge(60);
            response.addCookie(cookie);

        int sum = 0;
        for(Goods a :map1.keySet()){
            sum +=a.getPrice()*(map1.get(a));
            System.out.println("总价"+sum);
        }

        model.addAttribute("Tprice",sum);



        i++;
        System.out.println("提交"+i);


        return "cartView";
    }




    //加入购物车，在session中创建购物车集合。
    //@ResponseBody
    @RequestMapping("doaddCart")
    public String addCart(HttpServletRequest request,int id,Model model){

        System.out.println("添加"+id);

        HttpSession session1 = request.getSession();
        Map<Goods,Integer> map = (Map<Goods, Integer>) session1.getAttribute("cartlist");
        if(map==null){
            map = new HashMap<Goods,Integer>();
            session1.setAttribute("cartlist",map);
        }

        if(!map.containsKey(bill.get(id-1))){//得准确找到那个元素。
            map.put(bill.get(id-1),1);
        }else{
            System.out.println("已经购买"+id);
            map.put(bill.get(id-1),map.get(bill.get(id-1))+1);
        }

        session1.setAttribute("bill",map);


        return "redirect:doview";//提交订单，但是不跳转页面。
    }



      static ArrayList<Goods> bill = new ArrayList<>();

    static{
        Goods g1 = new Goods(1,"小米手机1",2000.0);
        Goods g2 = new Goods(2,"小米手机2",2000.0);
        Goods g3 = new Goods(3,"小米手机3",2000.0);
        Goods g4 = new Goods(4,"小米手机4",2000.0);
        Goods g5 = new Goods(5,"小米手机5",2000.0);

        bill.add(g1);
        bill.add(g2);
        bill.add(g3);
        bill.add(g4);
        bill.add(g5);

    }


    //承接开始购物，来展示数据
    //@ResponseBody
    @RequestMapping("doview")
    public  String doview(Model model){

        model.addAttribute("billMap",bill);//得到的是Map集合。
        return "goodsview";                         //对象传错，那边数据加载不出来，所以出不来。

    }
}
