package com.itheima.controller;

import java.util.ArrayList;

public class test {
    ArrayList<String> a = new ArrayList<>();
}
