package com.itheima.test;
import java.util.ArrayList;
import java.util.Arrays;

public class Name1 {
    public static void main(String[] args){

        //调用a1方法//里面传入你所要的行数
        a1(10);//打印10行
    }


    public static void a1(int n){
        ArrayList<Integer> a1 = new ArrayList<Integer>();
        ArrayList<Integer> a2 = new ArrayList<Integer>();
        a1.add(0);
        a1.add(1);
        a1.add(0);


        System.out.println("[1]");

        if(n>0){

            for(int i1=0;i1<n;i1++) {
                a2.clear();
              for (int i = 0; i < a1.size() - 1; i++) {
                a2.add(a1.get(i) + a1.get(i + 1));
              }
                System.out.println(Arrays.toString(a2.toArray()));
            a2 = a21(a2);
            a1.clear();
            a1.addAll(a2);
            //System.out.println(Arrays.toString(a2.toArray()));
        }
        }
    }

    public static ArrayList<Integer> a21(ArrayList<Integer> a){
        ArrayList<Integer> a3 = new ArrayList<Integer>();
        a3.add(0);
        a3.addAll(a);
        a3.add(0);
        return a3;
    }
}
