package com.itheima.filter;

import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


@WebFilter("/*")
@Component
public class SuccessFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("init....");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        System.out.println("都拦截了");

        HttpServletRequest req = (HttpServletRequest)request;
        String path = req.getRequestURI();

        HttpServletResponse resp = (HttpServletResponse)response;
        HttpSession session = req.getSession();

        //如果是login放行。
        //如果放行login但是他又拦截dologin
        if(path.endsWith("login.html")||path.endsWith("dologin")){
            System.out.println(111111111);
            if(session.getAttribute("username")!=null&&session.getAttribute("password")!=null){
                System.out.println("######################################################");
                resp.sendRedirect("sucess.html");
                System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&");
                return;//交叉了
            }

          chain.doFilter(request,response);
          return;////////////////////////////////////////////////////////////////////////////////////return什么啊
            //#######################################
        }
        //我放行了，
        //分为拦截和不拦截两部分。不能同时冲突。

        //两种过滤方式，一种是根据文件名，一种是根据session中又没哟要存的值。
        //最有都是放过请求，不能是转发。
        //每种都有一种放行方式。


System.out.println("董鹏");

        //过滤出来怎么办

        //判断没被放行的页面，的session是不是空，是空的话重定向到登陆页面。
        //两种不同的条件。
        if(session.getAttribute("username")==null||session.getAttribute("password")==null){
            System.out.println(22222);
            resp.sendRedirect("login.html");
        }else{
            System.out.println(3333333);
            //resp.sendRedirect("sucess.html");//转到session，不代表这放行//刚才已经做好自动登陆了，没有输入密码不让登录。
            //不等于空，已经有session
            chain.doFilter(request,response);//直接访问的我页面本身，为什么访问不过去，最后的关键是放开请求。//没有放行
        }
    }

    @Override
    public void destroy() {
        System.out.println("destroy...");
    }
}
