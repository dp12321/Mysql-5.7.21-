package com.itheima.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
public class Login {

    //过滤器，在直接访问success.html进行判断，就拦截这个网页，判断




    //@ResponseBody
    @RequestMapping("dologin")//从方法跳转一定要注意声明。
    public String tologin(HttpServletRequest request,String username, String password ,String auto ,HttpServletResponse response){
        HttpSession session =  request.getSession();

        System.out.println("###"+username+"####"+password+"###");

        if(username==null){
            System.out.println("true");
        }else{
            System.out.println("false");
        }

        if(password==null){
            System.out.println("true");
        }else{
            System.out.println("false");
        }

        if(username.equals("")&&password.equals("")){
            System.out.println("true");
        }


        if(auto!=null){

            System.out.println("1111111111111");
                Cookie cookie = new Cookie("JSESSIONID",session.getId());
                System.out.println("22222222222222");
                cookie.setMaxAge(60);
                System.out.println("333333333333333333");
                response.addCookie(cookie);
                System.out.println("44444444444444444444");
        }


            //我忘了录入压根就没有null//还可以用null表示应该用""判断，就不是null，而是底下错了
             //if(username==null||password==null) {
             if(username.equals("")||password.equals("")) {                         //空间存储才有null
                if (session.getAttribute("username")==null || session.getAttribute("password")==null) {//居然得这么判断
                    //，我给你存的机会，就看你存不存，，既然没有，那我给你存一下

                        return "redirect:login.html";
                } else {
                    return "redirect:sucess.html";
                }
            }else{
            session.setAttribute("username",username);
            session.setAttribute("password",password);
            return "redirect:sucess.html";
            }

    //return "aa";
    }




    //test
    //@ResponseBody
    @RequestMapping("test")
    public String test(){
        return "index2";
    }
}
